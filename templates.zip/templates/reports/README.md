Reports of automated validation are saved in this folder.
